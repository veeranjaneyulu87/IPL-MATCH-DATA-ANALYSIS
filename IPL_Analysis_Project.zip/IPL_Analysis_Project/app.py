import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import os
from analysis import preprocess, season_winners_trend


# ---------------- PAGE CONFIG ----------------
st.set_page_config(page_title="IPL Analytics Dashboard", layout="wide", page_icon="🏏")


# ---------------- GLOBAL CSS ----------------
st.markdown("""
<style>

/* Main background */
.stApp {
    background-color: #F5F7FB;
}

/* Sidebar */
section[data-testid="stSidebar"] {
    background-color: #FFFFFF;
    border-right: 1px solid #E5E7EB;
}

/* Remove top padding */
.block-container {
    padding-top: 1rem;
}

/* Title */
h1, h2, h3 {
    color: #111827;
}

/* Metric Cards */
.metric-card {
    background: #FFFFFF;
    padding: 18px;
    border-radius: 12px;
    border: 1px solid #E5E7EB;
    box-shadow: 0px 4px 12px rgba(0,0,0,0.05);
    text-align: center;
}

/* Buttons */
.stButton>button {
    background-color: #2563EB;
    color: white;
    border-radius: 8px;
    border: none;
    padding: 10px 18px;
    font-weight: 600;
}
.stButton>button:hover {
    background-color: #1D4ED8;
}

/* Dataframe */
[data-testid="stDataFrame"] {
    border: 1px solid #E5E7EB;
    border-radius: 10px;
}

/* Footer */
.footer {
    text-align: center;
    color: #6B7280;
    font-size: 13px;
    padding-top: 20px;
}

</style>
""", unsafe_allow_html=True)


# ---------------- DATA LOADING ----------------
@st.cache_data
def load_data():
    path = os.path.join(os.path.dirname(__file__), "data", "matches.csv")
    df = pd.read_csv(path)
    df = preprocess(df)
    return df

df = load_data()


# ---------------- HEADER ----------------
st.markdown("""
<h1 style='text-align:center;'>🏏 IPL Analytics Dashboard</h1>
<p style='text-align:center; color:#6B7280; font-size:18px;'>
Team Performance & Winning Patterns (2008–2019)
</p>
""", unsafe_allow_html=True)


# ---------------- TOP METRICS ----------------
total_matches = len(df)
teams = pd.concat([df["team1"], df["team2"]]).unique()
seasons = df["match_year"].nunique()
venues = df["venue"].nunique()

c1, c2, c3, c4 = st.columns(4)

def metric(label, value):
    st.markdown(f"""
    <div class="metric-card">
        <div style="font-size:14px;color:#6B7280;">{label}</div>
        <div style="font-size:28px;font-weight:700;color:#111827;">{value}</div>
    </div>
    """, unsafe_allow_html=True)

with c1: metric("Total Matches", total_matches)
with c2: metric("Total Teams", len(teams))
with c3: metric("Seasons Covered", seasons)
with c4: metric("Venues", venues)

st.divider()


# ---------------- SIDEBAR ----------------
st.sidebar.title("📊 Navigation")
page = st.sidebar.radio(
    "",
    ["Home", "Team Performance", "Toss Analysis", "Venue Analysis", "Player Awards", "Season Trends"]
)


# ---------------- HOME ----------------
if page == "Home":
    st.subheader("Overview")

    st.write("""
This dashboard analyzes historical IPL match data and identifies:
- Team winning patterns
- Toss impact on results
- Venue advantages
- Player performances
    """)

    matches_by_team = pd.concat([df["team1"], df["team2"]]).value_counts().reset_index()
    matches_by_team.columns = ["team", "matches"]

    fig = px.bar(matches_by_team.head(10),
                 x="team", y="matches",
                 color="matches",
                 color_continuous_scale="Blues",
                 title="Top Teams by Matches Played")
    fig.update_layout(template="plotly_white")
    st.plotly_chart(fig, use_container_width=True)


# ---------------- TEAM PERFORMANCE ----------------
elif page == "Team Performance":
    st.subheader("Team Performance")

    teams_list = sorted(teams)
    team = st.selectbox("Select Team", teams_list)

    matches_played = df[(df["team1"] == team) | (df["team2"] == team)].shape[0]
    wins = df[df["winner"] == team].shape[0]
    win_pct = (wins / matches_played) * 100 if matches_played else 0

    c1, c2, c3 = st.columns(3)
    c1.metric("Matches Played", matches_played)
    c2.metric("Wins", wins)
    c3.metric("Win %", f"{win_pct:.1f}%")

    wins_by_season = df[df["winner"] == team].groupby("match_year").size().reset_index(name="wins")

    fig = px.bar(wins_by_season, x="match_year", y="wins",
                 title=f"{team} Wins Per Season",
                 color_discrete_sequence=["#10B981"])
    fig.update_layout(template="plotly_white")
    st.plotly_chart(fig, use_container_width=True)


# ---------------- TOSS ANALYSIS ----------------
elif page == "Toss Analysis":
    st.subheader("Toss Impact")

    df["toss_win_match"] = np.where(df["toss_winner"] == df["winner"], "Won Match", "Lost Match")
    toss_data = df["toss_win_match"].value_counts().reset_index()
    toss_data.columns = ["Result", "Count"]

    fig = px.pie(toss_data, names="Result", values="Count",
                 title="Does Toss Winner Win the Match?",
                 color_discrete_sequence=["#10B981", "#EF4444"])
    st.plotly_chart(fig, use_container_width=True)


# ---------------- VENUE ANALYSIS ----------------
elif page == "Venue Analysis":
    st.subheader("Venue Advantage")

    venue = st.selectbox("Select Venue", sorted(df["venue"].unique()))
    venue_df = df[df["venue"] == venue]

    wins = venue_df["winner"].value_counts().reset_index()
    wins.columns = ["Team", "Wins"]

    fig = px.bar(wins.head(10), x="Wins", y="Team", orientation="h",
                 title=f"Wins at {venue}",
                 color_discrete_sequence=["#F59E0B"])
    fig.update_layout(template="plotly_white")
    st.plotly_chart(fig, use_container_width=True)


# ---------------- PLAYER AWARDS ----------------
elif page == "Player Awards":
    st.subheader("Top Players")

    pom = df["player_of_match"].value_counts().reset_index()
    pom.columns = ["Player", "Awards"]

    fig = px.bar(pom.head(10), x="Awards", y="Player", orientation="h",
                 title="Top 10 Player of the Match Winners",
                 color_discrete_sequence=["#F59E0B"])
    fig.update_layout(template="plotly_white")
    st.plotly_chart(fig, use_container_width=True)

    st.dataframe(pom.head(20))


# ---------------- SEASON TRENDS ----------------
elif page == "Season Trends":
    st.subheader("Season Trends")

    matches_per_season = df.groupby("match_year").size().reset_index(name="matches")
    fig = px.line(matches_per_season, x="match_year", y="matches",
                  markers=True, title="Matches Per Season",
                  color_discrete_sequence=["#2563EB"])
    fig.update_layout(template="plotly_white")
    st.plotly_chart(fig, use_container_width=True)

    try:
        fig2, winners_df = season_winners_trend(df)
        st.plotly_chart(fig2, use_container_width=True)
        st.dataframe(winners_df)
    except:
        st.warning("Season winners data not available.")


